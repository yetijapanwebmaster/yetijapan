<?php

// force UTF-8 Ø

// Zenphoto theme definition file
$theme_description['name'] = 'Garland';
$theme_description['author'] = 'Mark Galeassi (aitf311) updated by Stephen Billard (sbillard) and Malte Müller (acrylian)';
$theme_description['version'] = '1.4.1';
$theme_description['date'] = '9/20/2007, updated 1/20/2011';
$theme_description['desc'] = gettext('Modded Wordpress theme from, <a href="http://garlandtheme.blogspot.com/">garland</a>');
?>