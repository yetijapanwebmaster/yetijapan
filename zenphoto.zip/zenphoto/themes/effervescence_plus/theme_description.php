<?php

// force UTF-8 Ø

// Zenphoto theme definition file
$theme_description['name'] = 'Effervescence+';
$theme_description['author'] = gettext('<a href="http://sblog.angoulvant.net/">Stephane Angoulvant</a> with modifications by <a href="http://stephen.sbillard.org/">Stephen Billard (sbillard)</a>');
$theme_description['version'] = '1.4.0';
$theme_description['date'] = '10/01/2008';
$theme_description['desc'] = gettext("Based on Effervescence 1.1 with multiple personalities (slimbox, simpleviewer and smoothgallery) added. Select different color schemes and personalities from the Admin Options tab.");
?>