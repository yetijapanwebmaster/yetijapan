<?php
// force UTF-8 Ø

if (!defined('WEBPATH')) die(); $themeResult = getTheme($zenCSS, $themeColor, 'light');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<?php zp_apply_filter('theme_head'); ?>
		<title><?php echo getBareGalleryTitle(); ?></title>
		<meta http-equiv="content-type" content="text/html; charset=<?php echo LOCAL_CHARSET; ?>" />
		<link rel="stylesheet" href="<?php echo pathurlencode($zenCSS); ?>" type="text/css" />
		<!--[if lt IE 10]>  <link rel="stylesheet" href="/zenphoto/themes/default/styles/sterile-light_IE.css">  <![endif]-->
		<?php printRSSHeaderLink('Gallery', gettext('Gallery RSS')); ?>
	</head>
	<body>
	<!--Begin YETI Elements-->
	<div id="welcome">	
<a href="/index.php"><img src="/images/welcome.png" class="fitframe"></a>
</div>

<div id="container">
	<div id="topbar">
		<div id="logo">
			<a href="/index.php"><img src="/images/yeti_transparent_small.png" class="fitframe"></a>
		</div>
		
		<?
                $a = file_get_contents("../menu.html");
                echo ($a);
                ?>

		</div>
		<!--End YETI elements //don't forget to add a closing div to to the very end-->
		<?php zp_apply_filter('theme_body_open'); ?>
		<div id="main">
			<div id="gallerytitle">
				<?php if (getOption('Allow_search')) {
					printSearchForm('');
				} ?>
				<h2><?php printHomeLink('', ' | ');
				echo getGalleryTitle(); ?></h2>
			</div>
			<div id="padbox">
				<?php printGalleryDesc(); ?>
				<div id="albums">
					<?php while (next_album()): ?>
						<div class="album">
							<div class="thumb">
								<a href="<?php echo html_encode(getAlbumLinkURL()); ?>" title="<?php echo gettext('View album:'); ?> <?php echo getAnnotatedAlbumTitle(); ?>"><?php printAlbumThumbImage(getAnnotatedAlbumTitle()); ?></a>
							</div>
							<div class="albumdesc">
								<h3><a href="<?php echo html_encode(getAlbumLinkURL()); ?>" title="<?php echo gettext('View album:'); ?> <?php echo getAnnotatedAlbumTitle(); ?>"><?php printAlbumTitle(); ?></a></h3>
								<small><?php printAlbumDate(""); ?></small>
								<p><?php printAlbumDesc(); ?></p>
							</div>
							<p style="clear: both; "></p>
						</div>
					<?php endwhile; ?>
				</div>
				<br clear="all" />
				<?php printPageListWithNav("&laquo; " . gettext("prev"), gettext("next") . " &raquo;"); ?>
			</div>
		</div>
		</div>
		<?php if (function_exists('printLanguageSelector')) {
			printLanguageSelector();
		} ?>
		<?php
		printAdminToolbox();
		zp_apply_filter('theme_body_close');
		?>
	</body>
</html>
