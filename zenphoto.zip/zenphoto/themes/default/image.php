<?php
// force UTF-8 Ø

if (!defined('WEBPATH')) die(); $themeResult = getTheme($zenCSS, $themeColor, 'light');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<?php zp_apply_filter('theme_head'); ?>
		<title><?php echo getBareGalleryTitle(); ?> | <?php echo getBareAlbumTitle(); ?> | <?php echo getBareImageTitle(); ?></title>
		<meta http-equiv="content-type" content="text/html; charset=<?php echo LOCAL_CHARSET; ?>" />
		<link rel="stylesheet" href="<?php echo pathurlencode($zenCSS); ?>" type="text/css" />
		<!--[if lt IE 10]>  <link rel="stylesheet" href="/zenphoto/themes/default/styles/sterile-light_IE.css">  <![endif]-->
		<?php if (zp_has_filter('theme_head', 'colorbox_css')) { ?>
			<script type="text/javascript">
				// <!-- <![CDATA[
				$(document).ready(function(){
					$(".colorbox").colorbox({
						inline:true,
						href:"#imagemetadata",
						close: '<?php echo gettext("close"); ?>'
					});
				});
				// ]]> -->
			</script>
		<?php } ?>
		<?php printRSSHeaderLink('Gallery', gettext('Gallery RSS')); ?>
	</head>
	<body>
	<!--Begin YETI Elements-->
	<div id="welcome">	
<a href="/index.php"><img src="/images/welcome.png" class="fitframe"></a>
</div>

<div id="container">
	<div id="topbar">
		<div id="logo">
			<a href="/index.php"><img src="/images/yeti_transparent_small.png" class="fitframe"></a>
		</div>
		
		<?
                $a = file_get_contents("../menu.html");
                echo ($a);
                ?>
		</div>
		<!--End YETI elements // don't forget to add a closing div to to the very end-->
		<?php zp_apply_filter('theme_body_open'); ?>
		<div id="main" style="border: ;">
			<div id="gallerytitle">
				<div class="imgnav" style="border: ;">
					<?php if (hasPrevImage()) { ?>
						<div class="imgprevious"><a href="<?php echo html_encode(getPrevImageURL()); ?>" title="<?php echo gettext("Previous Image"); ?>">&laquo; <?php echo gettext("prev"); ?></a></div>
					<?php } if (hasNextImage()) { ?>
						<div class="imgnext"><a href="<?php echo html_encode(getNextImageURL()); ?>" title="<?php echo gettext("Next Image"); ?>"><?php echo gettext("next"); ?> &raquo;</a></div>
					<?php } ?>
				</div>
				<h2>
					<span>
						<?php printHomeLink('', ' | '); ?>
						<a href="<?php echo html_encode(getGalleryIndexURL()); ?>" title="<?php gettext('Albums Index'); ?>"><?php echo getGalleryTitle(); ?></a> | 
						<?php
						printParentBreadcrumb("", " | ", " | ");
						printAlbumBreadcrumb("", " | ");
						?>
					</span>
					<?php printImageTitle(true); ?>
				</h2>
			</div>
			<!-- The Image -->
			<div id="image" style="border: ;">
				<strong>
					<?php
					$fullimage = getFullImageURL();
					if (!empty($fullimage)) {
						?>
						<a href="<?php echo html_encode($fullimage); ?>" title="<?php echo getBareImageTitle(); ?>">
							<?php
						}
						if (function_exists('printUserSizeImage') && isImagePhoto()) {
							printUserSizeImage(getImageTitle());
						} else {
							printDefaultSizedImage(getImageTitle());
						}
						if (!empty($fullimage)) {
							?>
						</a>
						<?php
					}
					?>
				</strong>
				<?php
				if (function_exists('printUserSizeImage') && isImagePhoto())
					printUserSizeSelector();
				?>
			</div>
			<div id="narrow" style="border: ;">
				<?php printImageDesc(true); ?>
				<?php if (function_exists('printSlideShowLink'))
					printSlideShowLink(gettext('View Slideshow')); ?>
				<hr /><br />
				<?php
				if (getImageMetaData()) {
					echo printImageMetadata(NULL, 'colorbox');
					?>
					<br clear="all" />
					<?php
				}
				printTags('links', gettext('<strong>Tags:</strong>') . ' ', 'taglist', '');
				?>
				<br clear="all" />

				<?php if (function_exists('printGoogleMap'))
					printGoogleMap(); ?>
				<?php if (function_exists('printRating')) {
					printRating();
				} ?>
				<?php if (function_exists('printShutterfly'))
					printShutterfly(); ?>

				<?php
				if (function_exists('printCommentForm')) {
					printCommentForm();
				}
				?>
			</div>
		</div>
		</div>
		<div height="70px; margin: 0 auto; display: block; clear: both; border: ;"></div>
		<?php
		printAdminToolbox();
		zp_apply_filter('theme_body_close');
		?>
	</body>
</html>
