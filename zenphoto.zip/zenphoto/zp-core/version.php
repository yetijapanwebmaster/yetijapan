<?php // This file contains version info only and is automatically updated. DO NOT EDIT.
define('ZENPHOTO_VERSION', '1.4.2.4');
define('ZENPHOTO_RELEASE', 10045);
define("RELEASE", true);
?>
